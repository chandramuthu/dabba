import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.css']
})
export class SortComponent implements OnInit {

  constructor(private dataService: DataService) { }

  ngOnInit() {
   
  }
  highToLow(){
    console.log("high to low clicked");
    this.dataService.sendData({from:"SortComponent", to:"ShoppingListComponent", event:"highToLow"});
  }


  lowToHigh(){
    console.log("Clicked Low to high");
    this.dataService.sendData({from:"SortComponent", to:"ShoppingListComponent", event:"lowToHigh"});
  }
}

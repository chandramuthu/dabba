import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {
  itemList: Array<any> = [];
  filteredItemList: Array<any> = [];

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.dataService.receiveData.subscribe((result) => {
      if (result && result.from === "AppComponent" && result.to === "ShoppingListComponent") {
        console.log(result);
        this.itemList = result.data;
        this.filteredItemList = JSON.parse(JSON.stringify(this.itemList));
      }
      else if (result && result.from === "FilterComponent" && result.to === "ShoppingListComponent") {
        console.log(result);
        // this.itemList = result.data;
        this.filteredItemList = this.filterItem(result.data.startRange, result.data.endRange, this.itemList);
      }
      else if (result && result.from === "SortComponent" && result.to === "ShoppingListComponent" && result.event === "highToLow"){
        console.log(result);
        this.highToLow(this.filteredItemList);
      }

      else if (result && result.from === "SortComponent" && result.to === "ShoppingListComponent" && result.event === "lowToHigh"){
        console.log(result);
        this.lowToHigh(this.filteredItemList);
      }

    }, (err) => {
      console.log(err);
    });

  }
  filterItem(startRange, endRange, itemList) {
    let filterArray = [];
    filterArray = itemList.filter((item) => {
      return item.price > startRange && item.price < endRange;
    })
    return filterArray;
  }

  highToLow(itemList){
    itemList.sort((a, b)=>{return b.price - a.price}); 
   
  }

  lowToHigh(itemList){
    itemList.sort((a, b)=>{return a.price - b.price}); 
   
  }

}

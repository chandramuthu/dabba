import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  rangeValues: number[] = [100, 1000];
startRange: number = 100;
endRange: number = 1000;
  constructor(private dataService: DataService) { }

  ngOnInit() {
  }
  priceRange(event) {
    let startRange = event.values[0];
    let endRange = event.values[1];
this.startRange = startRange;
this.endRange = endRange
    console.log(startRange);
    console.log(endRange);

  } 
  applyFilter(){
    this.dataService.sendData({ from: "FilterComponent", to: "ShoppingListComponent", data: { startRange:this.startRange, endRange: this.endRange } })


  }


}

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() {  }
  
  private dataServe = new BehaviorSubject<any>(null);
  receiveData = this.dataServe.asObservable();
  sendData(data: any) {
    this.dataServe.next(data);
    console.log(data);
  }
}


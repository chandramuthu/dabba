import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from './services/data.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ang-proj-cg-assessment-adobe';
  dataSource: any;
  constructor(private httpClient: HttpClient, private dataService:DataService) {
  }
  ngOnInit() {
    this.httpClient.get('https://api.myjson.com/bins/qzuzi').subscribe((res) => {
      this.dataSource = res;
      console.log(this.dataSource);
      this.dataService.sendData({from:"AppComponent", to:"ShoppingListComponent", data:this.dataSource})
    },(err:any)=>{
      console.log(err);
    });
    // this.dataService.receiveData.subscribe((data)=>{
    //   console.log(data);
    // },(err)=>{
    //   console.log(err);
    // });

  }

}

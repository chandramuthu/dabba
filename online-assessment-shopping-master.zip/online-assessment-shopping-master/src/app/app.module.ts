import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {SliderModule} from 'primeng/slider';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { SearchComponent } from './components/search/search.component';
import { ShoppingListComponent } from './components/shopping-list/shopping-list.component';
import { SortComponent } from './components/sort/sort.component';
import { CartIconComponent } from './components/cart-icon/cart-icon.component';
import { FilterComponent } from './components/filter/filter.component';
import { MainComponent } from './components/main/main.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SearchComponent,
    ShoppingListComponent,
    SortComponent,
    CartIconComponent,
    FilterComponent,
    MainComponent
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    SliderModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
